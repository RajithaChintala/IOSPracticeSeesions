//
//  ViewController.swift
//  TemperatureCheck
//
//  Created by Chintala,Rajitha on 2/28/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var inputFieldOL: UITextField!
    var temp1=0.0
    //var temp2=16
    //var temp3=0
    
    @IBOutlet weak var imageViewOL: UIImageView!
    
    @IBOutlet weak var descriptionView: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func ButtonField(_ sender: Any) {
        temp1=Double(inputFieldOL.text!)!
        if(temp1>=38){
            imageViewOL.image=UIImage(named:"HOT")
            descriptionView.text="It's HOT"
        }
        else if(temp1==17){
            imageViewOL.image=UIImage(named:"Normal")
            descriptionView.text="Temperature is Normal"
        }
        else {
        imageViewOL.image=UIImage(named:"Cold")
        descriptionView.text="It's Freezing"
        }
    }
    
}

