//
//  ViewController.swift
//  Chintala_Assignment02
//
//  Created by Chintala,Rajitha on 2/2/23.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var firstNameOutlet: UITextField!
    
    @IBOutlet weak var lastNameOutlet: UITextField!
    
    @IBOutlet weak var yearOutlet: UITextField!
    
    @IBOutlet weak var detailsLabel: UILabel!
    
    
    @IBOutlet weak var fullNameLabel: UILabel!
    
    @IBOutlet weak var initialsLabel: UILabel!
    
    
    @IBOutlet weak var ageLabel: UILabel!
    
    
    @IBAction func submitBTN(_ sender: UIButton) {
        
        var fn=firstNameOutlet.text!
        var ln=lastNameOutlet.text!
        var dob=yearOutlet.text!
        
        detailsLabel.text="Details"
        fullNameLabel.text="Full Name : \(ln) \(fn)"
        initialsLabel.text="Initials : \(ln[ln.startIndex]) \(fn[fn.startIndex])"
        ageLabel.text="Age : "+String(2023-Int(dob)!)
        
        
    }
    
    @IBAction func resetBTN(_ sender: UIButton) {
        
        firstNameOutlet.text=""
        lastNameOutlet.text=""
        yearOutlet.text=""
        detailsLabel.text=""
        fullNameLabel.text=""
        initialsLabel.text=""
        ageLabel.text=""
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

