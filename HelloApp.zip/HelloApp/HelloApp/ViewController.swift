//
//  ViewController.swift
//  HelloApp
//
//  Created by Chintala,Rajitha on 1/24/23.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var inputOutlet: UITextField!
    
    @IBOutlet weak var inputLastNameOutlet: UITextField!
    
    @IBOutlet weak var displayLabelOutlet: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func submitButton(_ sender: UIButton) {
        //Read the input from the text field and store it in a variable.
        var input = inputOutlet.text!;
        var lastName = inputLastNameOutlet.text!;
        
        //Perform the String Interpolation and assigning to displayLabel.
        displayLabelOutlet.text="Hello, \(input) \(lastName)!"
        
        
        
    }
    
}

