//
//  ViewController.swift
//  Chintala_CalculatorApp
//
//  Created by Chintala,Rajitha on 2/16/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var resultOutlet: UILabel!
    var res1 = 0.0
    var res2 = 0.0
    var Result = 0.0
    var resOperator = "+"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        resultOutlet.text=""
    }
    
    @IBAction func AllClearButton(_ sender: UIButton) {
        resultOutlet.text = ""
        res1 = 0
        res2 = 0
        resOperator = "+"
        Result = 0
    }
    
    @IBAction func ClearButton(_ sender: UIButton) {
        resultOutlet.text?.removeLast();
    }
    
    @IBAction func DivisionButton(_ sender: UIButton) {
        resOperator="/"
        res1=Double(resultOutlet.text!)!
        resultOutlet.text=""
    }
    
    @IBAction func ButtonNine(_ sender: UIButton) {
        resultOutlet.text=resultOutlet.text!+"9"
    }
    
    @IBAction func ButtonEight(_ sender: UIButton) {
        resultOutlet.text=resultOutlet.text!+"8"
    }
    
    @IBAction func ButtonSeven(_ sender: UIButton) {
        resultOutlet.text=resultOutlet.text!+"7"
    }
    
    @IBAction func AddButton(_ sender: UIButton) {
        resOperator = "+"
        res1 = Double(resultOutlet.text!)!
        resultOutlet.text=""
    }
    
    @IBAction func ButtonSix(_ sender: UIButton) {
        resultOutlet.text=resultOutlet.text!+"6"
    }
    
    @IBAction func ButtonFive(_ sender: UIButton) {
        resultOutlet.text=resultOutlet.text!+"5"
    }
    
    @IBAction func ButtonFour(_ sender: UIButton) {
        resultOutlet.text=resultOutlet.text!+"4"
    }
    
    @IBAction func SubtractButton(_ sender: UIButton) {
        resOperator = "-"
        res1 = Double(resultOutlet.text!)!
        resultOutlet.text = ""
    }
    
    @IBAction func ButtonOne(_ sender: UIButton) {
        resultOutlet.text=resultOutlet.text!+"1"
    }
    
    @IBAction func ButtonTwo(_ sender: UIButton) {
        resultOutlet.text=resultOutlet.text!+"2"
    }
    
    @IBAction func ButtonThree(_ sender: UIButton) {
        resultOutlet.text=resultOutlet.text!+"3"
    }
    
    @IBAction func MultiplyButton(_ sender: UIButton) {
        resOperator = "*"
        res1 = Double(resultOutlet.text!)!
        resultOutlet.text = ""
    }
    
    @IBAction func ButtonZero(_ sender: UIButton) {
        resultOutlet.text=resultOutlet.text!+"0"
    }
    
    @IBAction func PointButton(_ sender: UIButton){
        resultOutlet.text=resultOutlet.text!+"."
    }
    
    @IBAction func PercentileButton(_ sender: UIButton) {
        resOperator = "%"
        res1 = Double(resultOutlet.text!)!
        resultOutlet.text = ""
    }
    
    @IBAction func OutputButton(_ sender: UIButton) {
        if res2 == 0.0
        {
           res2 = Double(resultOutlet.text!)!
                }
                switch resOperator{
                case "+":
                    Result = res1+res2
                    
                    resultOutlet.text = String(Int(Result))
                case "*":
                    Result = res1*res2
                    resultOutlet.text = String(Int(Result))
                case "/":
                    if res2 != 0
                    {
                        Result = res1/res2
                        resultOutlet.text = String(format:"%.5f",Result)
                    }
                    else
                    {
                        resultOutlet.text="Not a number"
                    }
                case "%":
                    Result = res1.truncatingRemainder(dividingBy:res2)
                    resultOutlet.text = String(format:"%.1f",Result)
                case "-":
                    Result = res1-res2
                    resultOutlet.text = String(Int(Result))
                default:
                    resultOutlet.text = "Error"
            }
    }
    
    @IBAction func AddOrSubButton(_ sender: UIButton) {
        res2 = Double(resultOutlet.text!)!
        if resOperator == "+"
        {
           resOperator = "-"
        }
        else {
            resOperator="+"
        }
        resultOutlet.text=""
    }
}

