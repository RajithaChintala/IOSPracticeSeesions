//
//  ViewController.swift
//  Chintala_WordGuess
//
//  Created by Chintala,Rajitha on 3/26/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var wordsGuessedLabel: UILabel!
    @IBOutlet weak var wordsRemainingLabel: UILabel!
    @IBOutlet weak var totalWordsLabel: UILabel!
    @IBOutlet weak var userGuessLabel: UILabel!
    @IBOutlet weak var guessLetterField: UITextField!
    @IBOutlet weak var guessLetterButtonPressed: UIButton!
    @IBOutlet weak var hintLabel: UILabel!
    @IBOutlet weak var guessCountLabel: UILabel!
    @IBOutlet weak var statusLabel: UILabel!
    @IBOutlet weak var playAgainButtonPressed: UIButton!
    @IBOutlet weak var displayImage: UIImageView!
    
    let words = [["COW","Animal","img01"],["JAVA","Programming Langauage","img02"],["MOISTURIZER","SkinCare","img03"],["HANDBAG","Money Carrying Object","img04"],["BAGEL","Food Item","img05"]]
        
        var count = 0;
        var word = ""
        var lettersGiven = ""
        var CorrectGuessed = ""
        var remainingLetters = ""
        var finalWord = ""
        var display = ""
        var maxGuesses = 10
        var incorrectGuess = 0
        var noOfWords = 0
        
        
        override func viewDidLoad() {
            super.viewDidLoad()
            // Do any additional setup after loading the view.
            guessLetterButtonPressed.isEnabled = false
            word = words[0][0]
            updateUnderscores(word: word)
            guessCountLabel.text = "You have made \(count) Guesses"
            CorrectGuessed = wordsGuessedLabel.text!
            remainingLetters = wordsRemainingLabel.text!
            finalWord = totalWordsLabel.text!
            wordsGuessedLabel.text = CorrectGuessed+"0"
            wordsRemainingLabel.text = remainingLetters+"\(words.count)"
            totalWordsLabel.text = finalWord+"\(words.count)"
            hintLabel.text = "Hint: "+words[0][1]
            playAgainButtonPressed.isHidden=true
            statusLabel.isHidden = true
        }

    @IBAction func guessLetterButton(_ sender: UIButton) {
        count = count + 1
                var letter = guessLetterField.text?.last
                if(incorrectGuess<maxGuesses){
                    if(word.contains(letter!)){
                        lettersGiven = lettersGiven+"\(letter)"
                        var revealedWord = ""
                        for l in word{
                            if(lettersGiven.contains(l)){
                                revealedWord = revealedWord+"\(l)"
                            }
                            else{
                                revealedWord = revealedWord+" _"
                            }
                        }
                        userGuessLabel.text = revealedWord
                        guessLetterField.text = ""
                        if(!revealedWord.contains("_")){
                            playAgainButtonPressed.isHidden = false
                            playAgainButtonPressed.isEnabled = true
                            guessLetterButtonPressed.isEnabled = false
                            displayImage.image = UIImage(named: words[noOfWords][2])
                            noOfWords = noOfWords+1
                            wordsGuessedLabel.text = CorrectGuessed+" \(noOfWords)"
                            wordsRemainingLabel.text = remainingLetters+" \(words.count-noOfWords)"
                            guessCountLabel.text = "Wow! You have made \(count) guesses"
                        }
                        else{
                            guessLetterButtonPressed.isEnabled = false
                            guessCountLabel.text = "You have made \(count) Guesses"
                        }
                    }
                    else{
                        incorrectGuess = incorrectGuess+1
                        guessCountLabel.text = "You have made \(count) Guesses"
                    }
                }else{
                    
                    guessCountLabel.text = "you have used all the available\n guesses,Please Play again"
                    playAgainButtonPressed.isHidden = false
                    playAgainButtonPressed.isEnabled = true
                    guessLetterButtonPressed.isEnabled = false
                    guessLetterField.text = ""
                }
    }
    
    @IBAction func guessingLetterLabel(_ sender: UITextField) {
        if(guessLetterField.text != ""){
                    guessLetterButtonPressed.isEnabled = true
                }
                else{
                    guessLetterButtonPressed.isEnabled = false
                }
    }
    
    
    @IBAction func playAgainButton(_ sender: UIButton) {
        incorrectGuess = 0
                count = 0
                lettersGiven=""
                if(noOfWords == words.count){
                    statusLabel.isHidden = false
                    statusLabel.text = "Congratulations! You are done with the game!\nPlease start over again"
                displayImage.image = UIImage(named: "img06")
                userGuessLabel.isHidden = true
                guessCountLabel.text = ""
                noOfWords = 0
                wordsGuessedLabel.text = CorrectGuessed+"0"
                wordsRemainingLabel.text = remainingLetters+"\(words.count)"
                guessLetterButtonPressed.isEnabled = false
                hintLabel.text = ""
                guessLetterField.text = ""
                }
                else {
                    playAgainButtonPressed.isEnabled = false
                    word = words[noOfWords][0]
                    guessLetterButtonPressed.isEnabled = true
                    updateUnderscores(word: word)
                    hintLabel.text = "Hint: \(words[noOfWords][1])"
                    displayImage.image = UIImage(named: "DUMMY")
                    userGuessLabel.isHidden = false
                    guessLetterField.text = ""
                }
    }
    
    func updateUnderscores(word:String){
            display = ""
        for letter in word{
            display = display+"_ "
        }
            userGuessLabel.text = display
      }
    
    
    
    
    
    
    
}
