//
//  ViewController.swift
//  AnimationsDemo
//
//  Created by Chintala,Rajitha on 4/9/23.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var displayImage: UIImageView!
    @IBOutlet weak var HappyOL: UIButton!
    
    @IBOutlet weak var SadOL: UIButton!
    @IBOutlet weak var AngryOL: UIButton!
    @IBOutlet weak var CryOL: UIButton!
    @IBOutlet weak var ShowOL: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(_ animated: Bool) {
            //Move the image view outside of the screen view.
            displayImage.frame.origin.x = view.frame.maxX
            
            //Similarly, move other components as well outside of the screen
            
            HappyOL.frame.origin.x = view.frame.width
            
            SadOL.frame.origin.x = view.frame.width
            
            AngryOL.frame.origin.x = view.frame.width
            
            CryOL.frame.origin.x = view.frame.width
    }

    @IBAction func HappyActnBTN(_ sender: UIButton) {
        updateAndAnimate("Happy")
    }
    
    @IBAction func SadActnBTN(_ sender: UIButton) {
        updateAndAnimate("Sad")
    }
    
    @IBAction func AngryActnBTN(_ sender: UIButton) {
        updateAndAnimate("Angry")
    }
    
    @IBAction func CryActnBTN(_ sender: UIButton) {
        updateAndAnimate("Crying")
    }
    
    @IBAction func ShowActnBTN(_ sender: UIButton) {
        UIView.animate(withDuration: 1, animations: {
                    //Move all the compoenets to the center and disable show button
                    self.displayImage.center.x = self.view.center.x
                    
                    self.HappyOL.center.x = self.view.center.x;
                    
                    self.SadOL.center.x = self.view.center.x;
                    
                    self.AngryOL.center.x = self.view.center.x;
                    
                    self.CryOL.center.x = self.view.center.x
                    
                })
                
                ShowOL.isEnabled = false
    }
    
    func updateAndAnimate(_ imageName : String){
            
            //making the current image opaque.
            UIView.animate(withDuration: 1, animations: {
                self.displayImage.alpha = 0
            })
            
            //Assign the new image with animation and make it transparent. (alpha = 1)
            
            UIView.animate(withDuration: 1, delay:0.5, animations: {
                self.displayImage.alpha = 1
                self.displayImage.image = UIImage(named: imageName)
            })
    }
}
