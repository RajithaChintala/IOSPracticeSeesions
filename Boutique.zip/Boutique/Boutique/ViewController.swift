//
//  ViewController.swift
//  Boutique
//
//  Created by Chintala,Rajitha on 2/28/23.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var inputField: UITextField!
    
    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var descriptionLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func ButtonField(_ sender: UIButton) {
        //displayImage
        //displayText
        if(inputField.text=="Western"){
            imageView.image=UIImage(named:"modern")
            descriptionLabel.text="Displaying the Western Collection"
        }
        else if(inputField.text=="Indian Wear"){
            imageView.image=UIImage(named:"Traditional")
            descriptionLabel.text="Displaying the Traditional Collection"
        }
        else{
            inputField.text="Black"
            imageView.image=UIImage(named:"burkha")
            descriptionLabel.text="Displaying the Muslims outfit"
        }
        
    }
    
    
}

