//
//  ViewController.swift
//  Palavelli_SurgeryCostApp
//
//  Created by Palavelli,Bala Harinadh on 2/28/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var SurgeryLabel: UILabel!
    
    @IBOutlet weak var PatientOL: UITextField!
    
    @IBOutlet weak var SurgeryOL: UITextField!
    
    @IBOutlet weak var CostOL: UITextField!
    
    @IBOutlet weak var imageViewOL: UIImageView!
    
    @IBOutlet weak var DisplayLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func ButtonClicked(_ sender: UIButton) {
    
        var TotalSurgeryCost=0.0
        var SurgeryCost=0.0
        var Tax=0.0
        var HealthInsurance=0.0
        
        if(SurgeryOL.text!=="" || PatientOL.text!=="" || CostOL.text!==""){
            DisplayLabel.text!="Enter All the Details"
            imageViewOL.image = UIImage(named: "noResults")

        }
        
        else {
            if(SurgeryOL.text!=="Heart"){
                SurgeryCost=Double(CostOL.text!)!
                imageViewOL.image = UIImage(named: "Heart")
                TotalSurgeryCost=SurgeryCost*(1+(11.75/100))-500
                DisplayLabel.text!="\(PatientOL.text!) Total Cost For Heart🫀 Surgery is \(TotalSurgeryCost)"
            }
            else if(SurgeryOL.text!=="Knee"){
                SurgeryCost=Double(CostOL.text!)!
                imageViewOL.image = UIImage(named: "Knee")
                TotalSurgeryCost=SurgeryCost*(1+6.25/100)-350
                DisplayLabel.text!="\(PatientOL.text!) Total Cost For Knee Surgery is \(TotalSurgeryCost)"
            }
            else if(SurgeryOL.text!=="Brain"){
                SurgeryCost=Double(CostOL.text!)!
                imageViewOL.image = UIImage(named: "Brain")
                TotalSurgeryCost=SurgeryCost*(1+13.5/100)-750
                DisplayLabel.text!="\(PatientOL.text!): Total Cost For Brain Surgery is \(round((TotalSurgeryCost*100)/100.0))"
            
        }
        }
    }
    
}

