//
//  ViewController.swift
//  ConversionMVC
//
//  Created by Ashritha Ponugoti on 4/4/23.
//

import UIKit

class HomeViewController: UIViewController {
    @IBOutlet weak var metersOutlet: UITextField!
    @IBOutlet weak var centimetersOL: UITextField!
    
    var convertingNum = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func metersEntered(_ sender: Any) {
        if(metersOutlet.text == ""){
            centimetersOL.isEnabled = true
            centimetersOL.isHidden = false
        }else if(metersOutlet.text != ""){
            centimetersOL.isEnabled = false
            centimetersOL.isHidden = true
        }
    }
    
    @IBAction func centimetersEntered(_ sender: Any) {
        if(centimetersOL.text == ""){
            metersOutlet.isEnabled = true
            metersOutlet.isHidden = false
        }else if(centimetersOL.text != ""){
            metersOutlet.isEnabled = false
            metersOutlet.isHidden = true
        }
    }
    
    @IBAction func submitted(_ sender: Any) {
        var cms = Double(centimetersOL.text!)
        var m = Double(metersOutlet.text!)
        if(metersOutlet.text == ""){
            convertingNum = cms!/100
        }else if(centimetersOL.text == ""){
            convertingNum = m!*100
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
                
                if transition == "ResultSegue"{
                    var destination = segue .destination as! ResultViewController
                    
                    
                    if(centimetersOL.text != ""){
                        destination.cms = centimetersOL.text!
                        destination.res = String(convertingNum)
                    }
                    if(metersOutlet.text != ""){
                        destination.meters = metersOutlet.text!
                        destination.res = String(convertingNum)
                    }
                    
                }
    }
    
    
    
}

