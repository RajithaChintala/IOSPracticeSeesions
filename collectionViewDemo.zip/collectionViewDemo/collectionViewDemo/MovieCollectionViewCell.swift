//
//  MovieCollectionViewCell.swift
//  collectionViewDemo
//
//  Created by Chintala,Rajitha on 4/20/23.
//

import UIKit

class MovieCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageViewOL: UIImageView!
    
    //create a function to assign movies to image cell
    func assignMovies(movie : Movie){
        imageViewOL.image = movie.image
    }
    
}
