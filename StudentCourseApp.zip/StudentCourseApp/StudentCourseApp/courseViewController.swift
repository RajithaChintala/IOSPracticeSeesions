//
//  courseViewController.swift
//  StudentCourseApp
//
//  Created by Chintala,Rajitha on 4/4/23.
//

import UIKit

class courseViewController: UIViewController {

    @IBOutlet weak var courseDetails: UILabel!
    var coursesArray:[Course] = []
        
    override func viewDidLoad() {
        super.viewDidLoad()
        for course in coursesArray {
            courseDetails.text = courseDetails.text! + course.title + "-" + course.sem + "\n"
        }
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
